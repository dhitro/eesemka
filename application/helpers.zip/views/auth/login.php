<?php 

var_dump($this->input->post());

?>